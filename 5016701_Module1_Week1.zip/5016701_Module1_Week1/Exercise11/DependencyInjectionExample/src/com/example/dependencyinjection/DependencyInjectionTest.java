package com.example.dependencyinjection;

public class DependencyInjectionTest {
    public static void main(String[] args) {
        // Create a repository instance
        CustomerRepository repository = new CustomerRepositoryImpl();

        // Inject the repository into the service
        CustomerService service = new CustomerService(repository);

        // Use the service to find a customer
        Customer customer = service.getCustomerById("10");

        // Display the customer details
        System.out.println(customer);
    }
}
