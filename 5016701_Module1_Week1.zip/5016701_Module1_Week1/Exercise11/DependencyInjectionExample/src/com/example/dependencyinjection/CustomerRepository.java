package com.example.dependencyinjection;

public interface CustomerRepository {
    Customer findCustomerById(String id);
}
