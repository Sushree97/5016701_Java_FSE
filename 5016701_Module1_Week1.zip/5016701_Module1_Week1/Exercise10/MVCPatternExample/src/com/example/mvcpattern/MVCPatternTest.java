package com.example.mvcpattern;

public class MVCPatternTest {
    public static void main(String[] args) {
        // Create a student model
        Student model = new Student("1", "Sushree", "A");

        // Create a view to display student details
        StudentView view = new StudentView();

        // Create a controller
        StudentController controller = new StudentController(model, view);

        // Display initial student details
        controller.updateView();

        // Update student details
        controller.setStudentName("Amrit");
        controller.setStudentGrade("B");

        // Display updated student details
        controller.updateView();
    }
}
