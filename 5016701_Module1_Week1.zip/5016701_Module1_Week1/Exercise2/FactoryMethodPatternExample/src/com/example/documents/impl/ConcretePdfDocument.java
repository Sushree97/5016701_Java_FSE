package com.example.documents.impl;

import com.example.documents.PdfDocument;

public class ConcretePdfDocument implements PdfDocument {
    @Override
    public void open() {
        System.out.println("Opening PDF Document");
    }
}
