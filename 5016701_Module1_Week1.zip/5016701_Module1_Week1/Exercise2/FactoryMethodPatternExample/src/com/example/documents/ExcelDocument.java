package com.example.documents;

public interface ExcelDocument {
    void open();
}
