package com.example.documents;

public interface WordDocument {
    void open();
}

