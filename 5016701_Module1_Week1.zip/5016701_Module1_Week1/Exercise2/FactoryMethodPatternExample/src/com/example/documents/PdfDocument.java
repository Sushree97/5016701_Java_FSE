package com.example.documents;

public interface PdfDocument {
    void open();
}
