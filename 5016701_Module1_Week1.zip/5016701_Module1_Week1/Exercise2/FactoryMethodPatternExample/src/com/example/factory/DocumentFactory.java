package com.example.factory;

import com.example.documents.WordDocument;
import com.example.documents.PdfDocument;
import com.example.documents.ExcelDocument;

public abstract class DocumentFactory {
    public abstract WordDocument createWordDocument();
    public abstract PdfDocument createPdfDocument();
    public abstract ExcelDocument createExcelDocument();
}
