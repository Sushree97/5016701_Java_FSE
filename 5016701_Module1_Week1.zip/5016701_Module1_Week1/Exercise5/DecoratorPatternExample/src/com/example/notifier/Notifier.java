package com.example.notifier;

public interface Notifier {
    void send(String message);
}
