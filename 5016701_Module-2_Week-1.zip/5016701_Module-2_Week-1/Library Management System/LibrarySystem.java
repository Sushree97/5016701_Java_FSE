import java.util.*;
class Book {
    private int bookId;
    private String title;
    private String author;

    public Book(int bookId, String title, String author) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
    }

    public int getBookId() {
        return bookId;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    @Override
    public String toString() {
        return "\nbookId : " + bookId + "\ntitle : " + title + "\nauthor : " + author;
    }
}

class LibraryManagement {
    private Book[] books;
    private int size;

    public LibraryManagement(Book[] books) {
        this.books = books;
        this.size = books.length;
    }
    public Book linearSearchByTitle(String title) {
        for (int i = 0; i < size; i++) {
            if (books[i].getTitle().equalsIgnoreCase(title)) {
                return books[i];
            }
        }
        return null;
    }
    public Book binarySearchByTitle(String title) {
        int left = 0;
        int right = size - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = books[mid].getTitle().compareToIgnoreCase(title);
            if (comparison == 0) {
                return books[mid];
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }
    public void sortBooksByTitle() {
        Arrays.sort(books, Comparator.comparing(Book::getTitle, String.CASE_INSENSITIVE_ORDER));
    }
}

public class LibrarySystem {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        Book[] books = {
            new Book(1, "The White Tiger", "Rabindra Nath Tagore"),
            new Book(2, "Gitanjali", "Rabindra Nath Tagore"),
            new Book(3, "The Discovery of India", "Jawaharlal Nehru"),
            new Book(4, "One Punch Man", "Yusuke Murata"),
            new Book(5, "One Piece", "Eiichiro Oda")
        };

        LibraryManagement library = new LibraryManagement(books);
        library.sortBooksByTitle();

        while (true) {
            System.out.println("\nLibrary Management System");
            System.out.println("1. Searching by Title (Linear Search)");
            System.out.println("2. Searching by Title (Binary Search)");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            int choice = scan.nextInt();
            scan.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter the title of the book to search: ");
                    String linearSearchTitle = scan.nextLine();
                    Book linearResult = library.linearSearchByTitle(linearSearchTitle);
                    if (linearResult != null) {
                        System.out.println("Found: " + linearResult);
                    } else {
                        System.out.println("Book not found.");
                    }
                    break;

                case 2:
                    System.out.print("Enter the title of the book to search: ");
                    String binarySearchTitle = scan.nextLine();
                    Book binaryResult = library.binarySearchByTitle(binarySearchTitle);
                    if (binaryResult != null) {
                        System.out.println("Found: " + binaryResult);
                    } else {
                        System.out.println("Book not found.");
                    }
                    break;

                case 3:
                    System.exit(0);
                    System.out.println("Exiting...");
                    return;

                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}