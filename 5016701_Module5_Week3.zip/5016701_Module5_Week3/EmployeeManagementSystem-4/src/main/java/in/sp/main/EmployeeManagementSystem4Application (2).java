package in.sp.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeManagementSystem4Application {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementSystem4Application.class, args);
	}

}
