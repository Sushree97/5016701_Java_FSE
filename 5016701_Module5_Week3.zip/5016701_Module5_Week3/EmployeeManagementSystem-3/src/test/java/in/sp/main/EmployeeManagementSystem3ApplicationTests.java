package in.sp.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeManagementSystem3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
