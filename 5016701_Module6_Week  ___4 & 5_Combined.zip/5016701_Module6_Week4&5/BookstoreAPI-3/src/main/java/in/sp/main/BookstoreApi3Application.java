package in.sp.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookstoreApi3Application {

	public static void main(String[] args) {
		SpringApplication.run(BookstoreApi3Application.class, args);
	}

}
