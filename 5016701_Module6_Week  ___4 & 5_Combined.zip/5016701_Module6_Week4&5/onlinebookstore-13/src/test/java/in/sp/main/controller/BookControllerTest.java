package in.sp.main.controller;

import in.sp.main.model.Book;
import in.sp.main.service.BookService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.Optional;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(BookController.class)
public class BookControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private BookService bookService;

    private Book sampleBook;

    @BeforeEach
    public void setup() {
        sampleBook = new Book(1L, "Sample Title", "Sample Author", 29.99);
    }

    @Test
    public void testGetAllBooks() throws Exception {
        when(bookService.getAllBooks()).thenReturn(Arrays.asList(sampleBook));

        mockMvc.perform(get("/api/books"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].title").value("Sample Title"))
                .andExpect(jsonPath("$[0].author").value("Sample Author"))
                .andExpect(jsonPath("$[0].price").value(29.99));
    }

    @Test
    public void testGetBookById() throws Exception {
        when(bookService.getBookById(1L)).thenReturn(Optional.of(sampleBook));

        mockMvc.perform(get("/api/books/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("Sample Title"))
                .andExpect(jsonPath("$.author").value("Sample Author"))
                .andExpect(jsonPath("$.price").value(29.99));
    }

    @Test
    public void testAddBook() throws Exception {
        when(bookService.addBook(ArgumentMatchers.any(Book.class))).thenReturn(sampleBook);

        mockMvc.perform(post("/api/books")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"title\": \"New Title\", \"author\": \"New Author\", \"price\": 19.99}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("Sample Title"))
                .andExpect(jsonPath("$.author").value("Sample Author"))
                .andExpect(jsonPath("$.price").value(29.99));
    }

    @Test
    public void testUpdateBook() throws Exception {
        when(bookService.updateBook(ArgumentMatchers.eq(1L), ArgumentMatchers.any(Book.class))).thenReturn(Optional.of(sampleBook));

        mockMvc.perform(put("/api/books/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"title\": \"Updated Title\", \"author\": \"Updated Author\", \"price\": 39.99}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("Sample Title"))
                .andExpect(jsonPath("$.author").value("Sample Author"))
                .andExpect(jsonPath("$.price").value(29.99));
    }

    @Test
    public void testDeleteBook() throws Exception {
        when(bookService.deleteBook(1L)).thenReturn(true);

        mockMvc.perform(delete("/api/books/1"))
                .andExpect(status().isNoContent());
    }
}
