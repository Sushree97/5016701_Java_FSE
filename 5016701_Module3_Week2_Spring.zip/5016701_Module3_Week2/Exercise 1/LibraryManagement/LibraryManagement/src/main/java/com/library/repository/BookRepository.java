package com.library.repository;

public class BookRepository {

    public void doSomething() {
        System.out.println("Repository action is being performed");
    }
}
